function Footer() {
  return (
    <footer>
      <p>&copy; Developed by <a href="" target="_blank" rel="noopener noreferrer">Megharaj</a>. All rights reserved.</p>
    </footer>
  );
}

export default Footer;